#include "PagRevolutionObject.h"



PagRevolutionObject::PagRevolutionObject()
{
}

PagRevolutionObject::PagRevolutionObject(std::vector<glm::vec2> points, unsigned int subdivisions, unsigned int slices):subdivisions(subdivisions),slices(slices)
{
	perfilOriginal = new PagSubdivisionProfile(points);
}


PagRevolutionObject::~PagRevolutionObject()
{
}

bool PagRevolutionObject::isValid()
{
	if ( !perfilSubdividido.valid() ) {
		return false;
	}
	return true;

}

bool PagRevolutionObject::has(PagRevObjParts part)
{
	if ( perfilSubdividido.has(part) ) {
		return true;
	}
	return false;
}

std::vector<PagPosNorm> PagRevolutionObject::getPositionsAndNormals(PagRevObjParts part)
{
	return posNorm;
}

unsigned int PagRevolutionObject::getNPoints(PagRevObjParts part)
{
	return posNorm.size();
}

std::vector<glm::vec3> PagRevolutionObject::getTangents(PagRevObjParts part)
{
	return tangentes;
}

std::vector<glm::vec2> PagRevolutionObject::getTextureCoords(PagRevObjParts part)
{
	return std::vector<glm::vec2>();
}

std::vector<GLuint> PagRevolutionObject::getIndices4PointCloud(PagRevObjParts part)
{
	return indicesNube;
}

std::vector<GLuint> PagRevolutionObject::getIndices4TriangleMesh(PagRevObjParts part)
{
	return indicesMalla;
}

void PagRevolutionObject::revolution(PagRevObjParts part){
	struct PagPosNorm objeto ;
	glm::vec3 punto;
	glm::vec3 normal; //Mismo calculo que posiciones
	int a = 0;
	int tam = points.size() - 1;
	if ( has(part) ) {
		switch ( part )
		{
		case PAG_BODY:

			double x, z;
			for ( int i = 2; i < tam - 2; ++i ) {
				for ( int j = 0; j < slices; ++j ) {

					a = j*((2 * glm::radians(180.0)) / slices);
					x = points [i].x * cos(a);
					z = points [i].x * -sin(a);

					punto.x = x;
					punto.y = points [i].y;
					punto.z = z;

					x = normales [i].x * cos(a);
					z = normales [i].x * -sin(a);
					normal.x = x;
					normal.y = normales [i].y;
					normal.z = z;

					objeto.position = punto;
					objeto.normal = normal;
					posNorm.push_back(objeto);
				}
			}
			break;
		case PAG_TOP_FAN: //Tapa Arria

			normal.x = 0;
			normal.y = 1;
			normal.z = 0;

			for ( int i = 0; i < slices; ++i ) {
				a = i*((2 * glm::radians(180.0)) / slices);
				x = points [points.size() - 2].x * cos(a);
				z = points [points.size() - 2].x * -sin(a);
				punto.x = x;
				punto.y = points [points.size() - 2].y;
				punto.z = z;

				objeto.position = punto;
				objeto.normal = normal;
				posNorm.push_back(objeto);
			}

			punto.x = points [points.size() - 1].x;
			punto.y = points [points.size() - 1].y;
			punto.z = 0;

			objeto.position = punto;
			objeto.normal = normal;
			posNorm.push_back(objeto);

			break;
		case PAG_BOTTOM_FAN: //Tapa Abajo

			normal.x = 0;
			normal.y = -1;
			normal.z = 0;

			punto.x = points [0].x;
			punto.y = points [0].y;
			punto.z = 0;

			objeto.position = punto;
			objeto.normal = normal;
			posNorm.push_back(objeto);
			for ( int i = 0; i < slices; ++i ) {
				a = i*((2 * glm::radians(180.0)) / slices);
				x = points [1].x * cos(a);
				z = points [1].x * -sin(a);
				punto.x = x;
				punto.y = points [1].y;
				punto.z = z;

				objeto.position = punto;
				objeto.normal = normal;
				posNorm.push_back(objeto);
			}

			break;
		}

	}
}

void PagRevolutionObject::uso(){
	perfilOriginal->clean();
	perfilSubdividido = perfilOriginal->subdivide(subdivisions);


	perfilSubdividido.mostrarPerfil();
	perfilSubdividido.calculoNormales();

	normales = perfilSubdividido.getNormales();
	points= perfilSubdividido.getPuntos();

}

void PagRevolutionObject::calculoTangentes(PagRevObjParts part){

	int a = 0;
	glm::vec3 tangente;
	tangente.y = 0;
	int tam = points.size();
	switch ( part )
	{
	case PAG_BODY:
		for ( int i = 0; i < tam; ++i ) {
			for ( int j = 0; j < slices; ++j ) {
				a = j*((2 * glm::radians(180.0)) / slices);
				tangente.x = -sin(a);
				tangente.z = -cos(a);
				tangentes.push_back(tangente);
			}
		}

		break;
	case PAG_TOP_FAN:
		glm::vec3 zPos (0, 0, 1);
		for ( int i = 0; i < tam; ++i ) {
			tangentes.push_back(glm::normalize(posNorm[i].normal * zPos));
		}
		break;
	case PAG_BOTTOM_FAN:
		glm::vec3 zNeg(0, 0, -1);
		for ( int i = 0; i < tam; ++i ) {
			tangentes.push_back(glm::normalize(posNorm [i].normal * zNeg));
		}

		break;
	}
}

void PagRevolutionObject::indicesMallaTriangulos(PagRevObjParts part)
{

	int tam = points.size();
	switch ( part )
	{
	case PAG_BODY:

		for ( int s = 0; s < slices; ++s ) {
			for ( int i = 0; i < tam; ++i ) {
				indicesMalla.push_back((i*(slices + 1)) + s);
				indicesMalla.push_back((i*(slices + 1)) + (s + 1));
			}
			indicesMalla.push_back(0xFFFF);
		}

		break;
	case PAG_TOP_FAN: //Tapa arriba

		for ( int s = 0; s < slices; ++s ) {
			for ( int i = 0; i < tam; ++i ) {
				indicesMalla.push_back((i*(slices + 1)) + s);
				indicesMalla.push_back((i*(slices + 1)) + (s + 1));
			}
			indicesMalla.push_back(0xFFFF);
		}

		break;
	case PAG_BOTTOM_FAN: //Tapa abajo

		for ( int s = 0; s < slices; ++s ) {
			for ( int i = 0; i < tam; ++i ) {
				indicesMalla.push_back((i*(slices + 1)) + s);
				indicesMalla.push_back((i*(slices + 1)) + (s + 1));
			}
			indicesMalla.push_back(0xFFFF);
		}

		break;
	}
}

void PagRevolutionObject::indicesNubePuntos(PagRevObjParts part)
{

	int tam = points.size();
	switch ( part )
	{
	case PAG_BODY:

		for ( int i = 0; i < slices*tam; ++i ) {
			indicesNube.push_back(i);
		}
		indicesNube.push_back(0xFFFF);

		break;
	case PAG_TOP_FAN:

		for ( int i = 0; i < slices*tam; ++i ) {
			indicesNube.push_back(i);
		}
		indicesNube.push_back(0xFFFF);

		break;
	case PAG_BOTTOM_FAN:

		for ( int i = 0; i < slices*tam; ++i ) {
			indicesNube.push_back(i);
		}
		indicesNube.push_back(0xFFFF);

		break;
	}
}
